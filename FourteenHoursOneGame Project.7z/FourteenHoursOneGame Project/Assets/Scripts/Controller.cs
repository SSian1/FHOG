﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor.SceneManagement;

public class Controller : MonoBehaviour
{
	public int boardWidth;
	public int boardHeight;
	public GameObject tile;
	public ulong score = 0;
	public GameObject player;
	public GameObject node;
	public GameObject prism;
	public Text scoreText;
	public Text deadText;

	void Start ()
	{
		for (int y = -boardHeight; y < boardHeight; y++)
		{
			for (int x = -boardHeight; x < boardWidth; x++)
			{
				GameObject o = Instantiate(tile, new Vector3(x, y, 5.0f), Quaternion.identity);
				o.transform.parent = this.transform;
			}
		}

		scoreText.text = "Score: " + score.ToString();
	}

	void Update()
	{
		if (Random.Range(0.0f, 1.0f) > 0.95f)
		{
			Vector3 v = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0f);
			v.Normalize();
			v *= 16f;

			if (Random.Range(0.0f, 1.0f) > 0.5f)
			{
				Instantiate(prism, player.transform.position + v, Quaternion.identity, transform);
			}
			else
			{
				Instantiate(node, player.transform.position + v, Quaternion.identity, transform);
			}
		}

		if (player)
		{
			score++;
			scoreText.text = "Score: " + score.ToString();
		}

		GameObject[] enemies = GameObject.FindGameObjectsWithTag("enemy");
		GameObject[] fProjectiles = GameObject.FindGameObjectsWithTag("friendly_projectile");
		GameObject[] eProjectiles = GameObject.FindGameObjectsWithTag("enemy_projectile");
		GameObject[] sProjectiles = GameObject.FindGameObjectsWithTag("super_projectile");

		for (int i = 0; i < enemies.Length; i++)
		{
			if (Vector3.Distance(enemies[i].transform.position, player.transform.position) < 1f)
			{
				Destroy(player);
				Destroy(enemies[i]);
				deadText.text = "YOU DEAD!";
				Application.Quit();
			}

			for (int j = 0; j < sProjectiles.Length; j++)
			{
				if (Vector3.Distance(enemies[i].transform.position, sProjectiles[j].transform.position) < 1f)
				{
					Destroy(enemies[i]);
				}
			}

			for (int j = 0; j < fProjectiles.Length; j++)
			{
				if (Vector3.Distance(enemies[i].transform.position, fProjectiles[j].transform.position) < 1f)
				{
					Destroy(enemies[i]);
					Destroy(fProjectiles[j]);
				}
			}
		}

		for (int i = 0; i < eProjectiles.Length; i++)
		{
			if (Vector3.Distance(eProjectiles[i].transform.position, player.transform.position) < 1f)
			{
				Destroy(player);
				Destroy(eProjectiles[i]);
				deadText.text = "YOU DEAD!";
				Application.Quit();
			}

			for (int j = 0; j < sProjectiles.Length; j++)
			{
				if (Vector3.Distance(eProjectiles[i].transform.position, sProjectiles[j].transform.position) < 1f)
				{
					Destroy(eProjectiles[i]);
				}
			}

			for (int j = 0; j < fProjectiles.Length; j++)
			{
				if (Vector3.Distance(eProjectiles[i].transform.position, fProjectiles[j].transform.position) < 1f)
				{
					Destroy(eProjectiles[i]);
					Destroy(fProjectiles[j]);
				}
			}
		}
	}
}
