﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LargeProjectile : PlayerProjectile
{
	public int timeToDeath = 50;
	public GameObject smallProjectile;
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		transform.position += (transform.rotation * Vector3.up) * projectileSpeed;

		timeToDeath--;

		if (timeToDeath == 0)
		{
			for (float theta = 0.0f; theta < 360f; theta += 30f)
			{
				Instantiate(smallProjectile, transform.position, Quaternion.AngleAxis(theta, Vector3.forward));
			}

			transform.position = new Vector3(4096f, 4096f, 4096f);
			GameObject.Destroy(this);
		}
	}
}
