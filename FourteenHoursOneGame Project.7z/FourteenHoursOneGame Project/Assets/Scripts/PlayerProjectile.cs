﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerProjectile : MonoBehaviour
{
	public float projectileSpeed = 1f;

	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		transform.position += (transform.rotation * Vector3.up) * projectileSpeed;

		if (transform.position.magnitude > 4096f) Destroy(this);
	}
}
