﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NodeAI : MonoBehaviour
{
	public GameObject player;
	public float nodeSpeed = 0.01f;

	void Start ()
	{
		player = GameObject.FindGameObjectWithTag("player");
	}
	
	void Update ()
	{
		Vector3 diff = player.transform.position - transform.position;
		diff.Normalize();

		this.transform.position += diff * nodeSpeed;
		this.transform.rotation *= Quaternion.Euler(0f, 0f, 1f);
	}
}
