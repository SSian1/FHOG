﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrismAI : MonoBehaviour
{
	public GameObject player;
	public GameObject prismProjectile;
	public float prismSpeed = 0.05f;
	
	private float fireTimeout = 2f;
	private float fireDuration = 2f;

	// Use this for initialization
	void Start ()
	{
		player = GameObject.FindGameObjectWithTag("player");
	}
	
	// Update is called once per frame
	void Update ()
	{
		Vector3 diff = player.transform.position - transform.position;
		diff.Normalize();
		float rotZ = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
		Quaternion rotator = Quaternion.Euler(0f, 0f, rotZ - 90);

		this.transform.position += diff * prismSpeed;

		fireTimeout -= Time.deltaTime;

		if (fireTimeout <= 0)
		{
			fireTimeout = fireDuration;
			Instantiate(prismProjectile, this.transform.position, rotator);
		}
	}
}
