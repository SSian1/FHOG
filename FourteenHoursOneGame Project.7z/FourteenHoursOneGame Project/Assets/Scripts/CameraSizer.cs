﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSizer : MonoBehaviour
{
	public float PPU = 3;
	public GameObject follow;

	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		Camera c = GetComponent<Camera>();

		c.orthographicSize = (Screen.height / (2.0f * PPU));
		c.transform.position = new Vector3(follow.transform.position.x, follow.transform.position.y, -10f);
	}
}
