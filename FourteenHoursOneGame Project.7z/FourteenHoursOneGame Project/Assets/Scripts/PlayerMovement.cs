﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
	public const float PLAYER_SPEED = 128F;
	public Rigidbody2D playerBody;

	public Animator animator;
	public Animator weaponAnimator;
	public int currentWeapon;

	public GameObject smallProjectile;
	public GameObject mediumProjectile;
	public GameObject largeProjectile;

	public Text lightText;
	public Text mediumText;
	public Text heavyText;

	//current number of rounds in a mag
	private int[] weaponAmmo = new int[] { 20, 10, 5 };

	//max number of rounds in a mag
	private int[] maxWeaponAmmo = new int[] { 120, 80, 10 };

	//time left until another round is completed
	private float[] weaponAmmoRecharge = new float[] { 0f, 0f, 0f };

	//how long it takes to recharge a round
	private float[] weaponAmmoRechargeValues = new float[] { 0.25f, 1f, 5f};

	//how long until another shot can be fired
	private float[] weaponRechargeTime = new float[3] { 0f, 0f, 0f };

	//how long it takes for another shot to be fired.
	private float[] weaponRechargeValues = new float[] { 0, 1, 2 };
	
	public Vector2 speed;
	public Vector2 location;
	public bool facingFront;

	// Use this for initialization
	void Start ()
	{
		location = new Vector2();
		speed = new Vector2();
	}
	
	// Update is called once per frame
	void Update ()
	{
		Vector2 input = new Vector2();

		if (Input.GetKey("w")) input.y += 1;
		if (Input.GetKey("s")) input.y -= 1;
		if (Input.GetKey("a")) input.x -= 1;
		if (Input.GetKey("d")) input.x += 1;
		Vector2 mPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		mPos.x -= transform.position.x;
		mPos.y -= transform.position.y;

		if (Input.GetMouseButton(0))
		{
			if (weaponAmmo[currentWeapon] > 0 &&
				weaponRechargeTime[currentWeapon] <= 0f)
			{
				input += mPos.normalized * -4.0f * (currentWeapon + 1);

				Vector3 diff = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
				diff.Normalize();
				float rotZ = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
				Quaternion rotator = Quaternion.Euler(0f, 0f, rotZ - 90);

				switch (currentWeapon)
				{
					case 0:
						Instantiate(smallProjectile, this.transform.position, rotator);
						break;
					case 1:
						Instantiate(mediumProjectile, this.transform.position, rotator);
						Instantiate(mediumProjectile, this.transform.position, rotator * Quaternion.Euler(0f, 0f, 10f));
						Instantiate(mediumProjectile, this.transform.position, rotator * Quaternion.Euler(0f, 0f, -10f));
						Instantiate(mediumProjectile, this.transform.position, rotator * Quaternion.Euler(0f, 0f, 20f));
						Instantiate(mediumProjectile, this.transform.position, rotator * Quaternion.Euler(0f, 0f, -20f));
						break;
					case 2:
						Instantiate(largeProjectile, this.transform.position, rotator);
						break;
					default:
						break;
				}
				weaponAmmo[currentWeapon]--;
				weaponRechargeTime[currentWeapon] = weaponRechargeValues[currentWeapon];
			}
		}

		for (int i = 0; i < 3; i++)
		{
			weaponAmmoRecharge[i] -= Time.deltaTime;
			weaponRechargeTime[i] -= Time.deltaTime;

			if (weaponAmmoRecharge[i] <= 0)
			{
				weaponAmmoRecharge[i] = weaponAmmoRechargeValues[i];
				weaponAmmo[i]++;
			}

			if (weaponAmmo[i] > maxWeaponAmmo[i]) weaponAmmo[i] = maxWeaponAmmo[i];
		}

		lightText.text = "Light: " + weaponAmmo[0].ToString();
		mediumText.text = "Medium: " + weaponAmmo[1].ToString();
		heavyText.text = "Heavy: " + weaponAmmo[2].ToString();

		speed += input * PLAYER_SPEED * Time.deltaTime;
		speed *= 0.8f;
		location += speed * Time.deltaTime;
		playerBody.MovePosition(location);


		if (mPos.x > 0)
		{
			transform.localScale = new Vector3(1f, 1f, 1f);
		}
		else if (mPos.x < 0)
		{
			transform.localScale = new Vector3(-1f, 1f, 1f);
		}

		if (mPos.y > 0f)
		{
			animator.SetBool("isFacingFront", false);
			facingFront = false;
		}
		else
		{
			animator.SetBool("isFacingFront", true);
			facingFront = true;
		}

		animator.SetBool("isMoving", speed.magnitude > 0.01f);

		if (Input.mouseScrollDelta.y > 0.0)
		{
			currentWeapon++;
		}
		else if (Input.mouseScrollDelta.y < 0.0)
		{
			currentWeapon--;
		}

		if (currentWeapon > 2) currentWeapon = 0;
		else if (currentWeapon < 0) currentWeapon = 2;

		weaponAnimator.SetInteger("currentWeapon", currentWeapon);
	}
}
